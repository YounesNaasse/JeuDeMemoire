# Exemple d'application Web à page unique

Ce dossier contient le code fron-end de l'IHM. Ce code illustre l'interface utilisateur du jeu de mémoire en tant qu'application Web à page unique.

## Exigences:

 - [Node.js] (https://nodejs.org/en/download/) - Veillez à sélectionner l'option permettant d'ajouter "Node" à votre PATH (variable d'environnement).

 - [Générateur express] (http://expressjs.com/fr/starter/generator.html) - Après avoir installé Node, installez Express en exécutant `npm install express-generator -g`

## Pour exécuter l'application:

 1. Copiez le dossier parent pour les exemples backend et frontend.

 2. Suivez les instructions README dans le dossier [. \ Backend] (.. \ backend \ README.md) pour démarrer le service API REST (sur [http: // localhost: 8000 /] (http: // localhost: 8000 /)).
 
 3. Ouvrez une fenetre cmd dans \ Frontend \ Final.

 4. Exécutez `npm install` pour installer les dépendances.
 
 5. Exécutez `npm start` pour démarrer le serveur Nodejs.

 6. Accédez à [http: // localhost: 3000 /]. Sélectionnez une nouvelle partie dans le menu déroulant et commencez à cliquer sur les cartes pour révéler leurs valeurs et trouver des correspondances.