var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Projet HTML5 - Jeu de Mémoire' });
});

module.exports = router;
