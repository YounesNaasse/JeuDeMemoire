var gameBoardSize = 0;
var cardsFlipped = 0;

var selectedCards = [];
var selectedCardsValues = [];

function newGame() {
    // Initialiser le jeux
    gameBoardSize = 0;
    cardsFlipped = 0;

    // récupérer la valeur à partir du menu déroulant dans le jeux
    var size = $("#selectGameSize").val();

    // parser l'entier de la chaine 
    size = parseInt(size, 10);


    // verifie la selection
    if (size === 0) {
        // message d'erreur
        alert("Please choose a size!");
    } else {
        //  recuperer le plateau de jeu à partir du serveu
        $.post("http://localhost:8000/new?size=" + size, function (response) {
            // dupliquer pour les numéros des cartes
            gameBoardSize = size * 2;

            // crée un plateau vide
            var board = [];
            for (var i = 0; i < gameBoardSize; i++) {
                board.push({
                    "cleared": "false",
                    "value": null
                });
            }

            // dessiner le plateau
            drawGameBoard(board);
        });
    }
}

function restoreGame() {
    // initialisation
    gameBoardSize = 0;
    cardsFlipped = 0;

    // recuperer le plateau de jeu à partir du serveu
    $.get("http://localhost:8000/game", function (response) {
        // recuperer la taille du plateau
        gameBoardSize = response.length;

        // dessiner le plateau
        drawGameBoard(response);
    });
}

function drawGameBoard(board) {
    // la variable de sortie
    var output = "";
    // taille du tableau css
    var css = "";
    switch (board.length / 4) {
        case 1:
            css = "rows1";
            break;
        case 2:
            css = "rows2";
            break;
        case 3:
            css = "rows3";
            break;
        case 4:
            css = "rows4";
            break;
    }
    // générer le code HTML de chaque carte et ajouter à la variable de sortie 
    for (var i = 0; i < board.length; i++) {
        if (board[i].cleared == "true") {
            // si la carte a été joué, on appel la classe flip
            output += "<div class=\"flipContainer col-xs-3 " + css + "\"><div class=\"cards flip matched\" id=\"" + i + "\" onClick=\"flipCard(this)\">\
				<div class=\"front\"><span class=\"glyphicon glyphicon-question-sign\"></span></div>\
				<div class=\"back\">" + lookUpGlyphicon(board[i].value) + "</div>\
				</div></div>";
        } else {
            output += "<div class=\"flipContainer col-xs-3 " + css + "\"><div class=\"cards\" id=\"" + i + "\" onClick=\"flipCard(this)\">\
				<div class=\"front\"><span class=\"glyphicon glyphicon-question-sign\"></span></div>\
				<div class=\"back\"></div>\
				</div></div>";
        }
    }
    // ajouter la sortie sur la page html
    $("#game-board").html(output);
}

function flipCard(card) {
    // Ne pas rejouer une carte retourner
    if ($(card).hasClass("flip")) {
        return;
    }

    // Selectionner deux carte maximum à la fois
    if (selectedCards.length < 2) {

        $(card).toggleClass("flip");

        // Vérifie si c'est la 1er ou la seconde carte selectionner
        if (selectedCards.length == 0) {
            // Enregistrer la 1er carte
            selectedCards.push(card.id);

            // envoyer cette combinaison au serveur et vérifier la valeur
            $.ajax({
                url: "http://localhost:8000/guess?card=" + selectedCards[0],
                type: 'PUT',
                success: function (response) {
                    // afficher la valeur de la 1er carte
                    $("#" + selectedCards[0] + " .back").html(lookUpGlyphicon(response[0].value));

                    // enregistrer la valeur de la 1er carte
                    selectedCardsValues.push(response[0].value);
                }
            });
        }
        else if (selectedCards.length == 1) {
            // Enregistrer la seconde carte
            selectedCards.push(card.id);

            // envoyer cette combinaison au serveur et vérifier la valeur
            $.ajax({
                url: "http://localhost:8000/guess?card=" + selectedCards[1],
                type: 'PUT',
                success: function (response) {
                    // afficher la valeur de la 1er carte
                    $("#" + selectedCards[1] + " .back").html(lookUpGlyphicon(response[0].value));

                    // enregistrer la valeur de la 1er carte
                    selectedCardsValues.push(response[0].value);

                    // vérifier si c'est une bonne combinaison
                    if (selectedCardsValues[0] == selectedCardsValues[1]) {
                        // incrémenter le compteur des carte retourner
                        cardsFlipped += 2;

                        // changer la class des cartes et les mettres sur matched
                        $("#" + selectedCards[0]).addClass("matched");
                        $("#" + selectedCards[1]).addClass("matched");

                        // réinitialiser les tableaux de sélection
                        selectedCards = [];
                        selectedCardsValues = [];

                        // vérifier si l'utilisateur a gagné la partie

                        if (cardsFlipped == gameBoardSize) {
                            setTimeout(function () {
                                output = "<div id=\"playAgain\"><p>You Win!</p><input type=\"button\" onClick=\"location.reload()\" value=\"Play Again\" class=\"btn\" /></div>";
                                $("#game-board").html(output);
                            }, 1000);
                        }

                    }
                    else {
                        // sinon, attendre et retourner les cartes
                        setTimeout(function () {
                            // réinitialiser la couleur du background
                            $("#" + selectedCards[0]).toggleClass("flip");
                            $("#" + selectedCards[1]).toggleClass("flip");

                            //réinitialiser les tableaux de sélection
                            selectedCards = [];
                            selectedCardsValues = [];
                        }, 1000);
                    }
                }
            });
        }
    }
}

// tableau des icone bootstrap 
var valuesMap = [
    {
        "value": "0",
        "glyphicon": "glyphicon glyphicon-cloud"
    },
    {
        "value": "1",
        "glyphicon": "glyphicon glyphicon-heart"
    },
    {
        "value": "2",
        "glyphicon": "glyphicon glyphicon-star"
    },
    {
        "value": "3",
        "glyphicon": "glyphicon glyphicon-home"
    },
    {
        "value": "4",
        "glyphicon": "glyphicon glyphicon-glass"
    },
    {
        "value": "5",
        "glyphicon": "glyphicon glyphicon-music"
    },
    {
        "value": "6",
        "glyphicon": "glyphicon glyphicon-fire"
    },
    {
        "value": "7",
        "glyphicon": "glyphicon glyphicon-globe"
    },
    {
        "value": "8",
        "glyphicon": "glyphicon glyphicon-tree-conifer"
    }
];

// recuperer l'icone en fonction de la valeur
function lookUpGlyphicon(value) {
    for (var i = 0; i < valuesMap.length; i++) {
        if (valuesMap[i].value == value) {
            return "<span class=\"" + valuesMap[i].glyphicon + "\"></span>";
        }
    }

    return value;
}
