# backend

Exemple d'API REST (API du jeu de mémoire)

Il s'agit du code complet pour la partie back-end du jeux. Ce code démontre la logique du jeu en utilisant un service d'API REST.

## Exigences:

  - [Node.js] (https://nodejs.org/en/download/) - Veillez à sélectionner l'option permettant d'ajouter un nœud à votre PATH.

## Pour exécuter l'échantillon:

  1. Copiez ce dossier et ouvrez votre invite de commande

  2. Exécutez `npm install` pour installer les dépendances.
 
  3. Exécutez `npm start` pour démarrer le serveur.

  4. Accédez à [http: // localhost: 8000 /], qui fournit une [interface utilisateur Swagger] (http://swagger.io/swagger-ui/) qui documente les opérations fourni par l'API du jeu de mémoire et fournit une interface de test manuelle.
