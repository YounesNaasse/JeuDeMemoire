Titre du projet : Developpement d'un jeux de mémoire avec Node.js, Express, Bootstrap, Pug et swagger

Description du projet :
	L'objectif de ce projet est le developpement d'une application web, à page unique, pour un jeux de mémoire, en utilisation les nouvelles technologies.
	
Le principe du jeu :
	Le jeu se compose de paires de cartes portant des illustrations identiques. L'ensemble des cartes est mélangé, puis étalé face caché. 
	Le joueur retourne deux cartes de son choix. S'il découvre deux cartes identiques, ces cartes restent retournées, ce qui lui permet de rejouer. 
	Si les cartes ne sont pas identiques, ils sont retournée faces cachées à leur emplacement de départ.
	Le jeu se termine quand toutes les paires de cartes ont été découvertes.
	Le joueur pourra choisir le nombre de cartes à jouer
	La logique du jeux a été générer par un service REST (Serveur du jeux). Cette partie a été récuperé depuis inetrnet, elle utilise Node.js et express.
	la partie IHM de l'application est un serveur à page unique developper avec nodejs, express et bootstrap.

equipe :
	Youness NAASSE

technologies utilisées
	nodejs
	express
	bootstrap
	swagger
	pug.js
	
	